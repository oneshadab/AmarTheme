Standard "Featured" module has no features to assign unique headers for each blocks and him shows goods strictly in order

Featured Plus improves standard "Featured" module
After installation, you can display the recommended products in random order, which is convenient when the number of selected products exceeds the specified limit for the output

As example:
you can select 20 products, set a display limit of 4 - and each time when page is loaded, in the "Featured" block will be shown 4 random goods of 20

Also adds the ability to assign separate multilanguageheaders for each block of recommended products right in its settings


Features:
---------
- showing featured products in random order
	if not selected - will be shown by default, in order of adding

- separate multilanguage headers for each block of recommended products
	if header is not filled for selected language - will be displayed standard header

- compatible with Opencart 2.x & 3.x
- does not change core files and DB


Install 2.x:
------------
1. Upload file ocmod.xml for your version in Extensions > Extension Installer
2. Refresh the Modifications cache in Extensions > Modifications
3. Check new features in Extensions > Module > Featured


Install 3.x:
------------
1. Upload archive featured_plus_3x.ocmod.zip in Extensions > Extension Installer
2. Refresh the Modifications cache in Extensions > Modifications
3. Check new features in Extensions > Module > Featured

Don`t forget refresh modification cache after install!



=======================
Thanks for your choise!

If you liked this module - please rate it on module page/your dowloads

More extensions:
https://www.opencart.com/index.php?route=marketplace/extension&filter_member=AlexDW